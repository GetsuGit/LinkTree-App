package com.example.linktree

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.view.menu.ActionMenuItemView
import androidx.recyclerview.widget.RecyclerView

class LinkAdapter(

    val items: List<LinkModel>,
    //onClick listener ke url
    val listener: AdapterListener,

): RecyclerView.Adapter<LinkAdapter.ViewHolder>() {

    class ViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
       // mengambil id
        val image = itemView.findViewById<ImageView>(R.id.image)
        val title = itemView.findViewById<TextView>(R.id.title)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder(
       // mengambil layout
        LayoutInflater.from(parent.context).inflate(R.layout.adapter_link, parent, false)
    )

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // set data
        val item = items[position]
        // terdapat image dan title
        holder.image.setImageResource(item.image)
        holder.title.text = item.title

        // ini url
        holder.itemView.setOnClickListener{
           listener.onClick(item)
        }

    }
    // mengambil total size
    override fun getItemCount() = items.size

    interface AdapterListener {
        fun onClick (linktree : LinkModel)

    }

}


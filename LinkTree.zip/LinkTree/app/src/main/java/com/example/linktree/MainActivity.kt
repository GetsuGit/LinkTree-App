package com.example.linktree

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // menyembunyikan bar
        supportActionBar!!.hide()

         val image = findViewById<ImageView>(R.id.image)
         val title = findViewById<TextView>(R.id.title)
         val subtitle = findViewById<TextView>(R.id.subtitle)
        // recyclerview
        val list = findViewById<RecyclerView>(R.id.list)


        image.setImageResource(R.drawable.avatar)
        title.text = "M. Rifki Nurdiansyah"
        subtitle.text = "Android Developer & Designer"

        list.adapter = linkAdapter
    }

    private val linkAdapter by lazy {
        // memanggil dan memasukan list dari linkadapter
        val items = listOf<LinkModel>(
            LinkModel("Instagram", R.drawable.ig, "https://www.instagram.com/getsudesign/"),
            LinkModel("Youtube", R.drawable.youtube, "https://www.youtube.com/channel/UCL6_jRIJOu5J3U7LxkcCD6A/videos"),
            LinkModel("Github", R.drawable.git, "https://github.com/GetsuGit"),
            LinkModel("WhatsApp", R.drawable.wa, "https://api.whatsapp.com/send?phone=6285216324924"),

        )
       LinkAdapter(items, object : LinkAdapter.AdapterListener {
           override fun onClick(linktree: LinkModel) {
              openUrl(linktree.url)
           }
       })
    }

    private fun openUrl(url: String){
        val openUrl = Intent(Intent.ACTION_VIEW)
        openUrl.data = Uri.parse(url)
        startActivity(openUrl)
    }

}
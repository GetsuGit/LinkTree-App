package com.example.linktree

class LinkModel(
       val title: String,
       val image: Int,
       val url: String,
)
